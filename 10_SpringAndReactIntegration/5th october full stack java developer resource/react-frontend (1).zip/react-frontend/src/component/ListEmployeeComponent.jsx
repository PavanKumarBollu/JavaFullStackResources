import React, { useState,useEffect } from 'react';
import {getEmployees} from "../services/EmployeeService"



function ListEmployeeComponent() {
    
  //employees <----setEmployees()
  const [employees, setEmployees] = useState([]);


  useEffect(() => {
    //Calling API From BackEnd to get the data of Employees
    getEmployees().then((emp) => {
     //Inject data to employees varaible
      setEmployees(emp.data);
    });
  }, []);

  return (
    <div className="m-4">
      <h2 className="text-center">Employees List</h2>
      <div className="row">
        <table className="table table-striped table-bordered">
          <thead>
            <tr>
              <th> Employee First Name</th>
              <th> Employee Last Name</th>
              <th> Employee Email Id</th>
              <th> Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr key={employee.id}>
                <td> {employee.firstName}</td>
                <td> {employee.lastName}</td>
                <td> {employee.emailId}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export default ListEmployeeComponent;