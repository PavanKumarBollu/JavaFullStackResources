import React from 'react';

function FooterComponent() {
  return (
    <div>
      <footer className="footer">
        <span className="text-muted">All Rights Reserved 2023 @Ineuron</span>
      </footer>
    </div>
  );
}

export default FooterComponent;