package in.ineuron.dao;

public interface ITransferDao {
	public String transferProductById(Integer id);
}
