package ai.neuron.beans;

public class PythonCourse implements Courses {

	
	public PythonCourse()
	{
		System.out.println("Python obj is created");
	}
	public boolean courseSelection() 
	{
		System.out.println("Python is selected");
		return true;

	}

}
