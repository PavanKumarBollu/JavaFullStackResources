package ai.neuron.util;

import org.springframework.stereotype.Component;

@Component
public class DateUtil 
{
	public DateUtil()
	{
		System.out.println("date obj created");
	}

}
