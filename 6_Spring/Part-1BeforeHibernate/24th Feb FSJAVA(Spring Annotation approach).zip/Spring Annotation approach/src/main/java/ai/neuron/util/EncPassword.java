package ai.neuron.util;

public class EncPassword 
{
	public EncPassword(String algorthm)
	{
		System.out.println("Pass word encrypted using algo");
		System.out.println("Algo use to do that "+algorthm);
	}

}
