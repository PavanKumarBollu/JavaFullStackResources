package in.ineuron.test;

import org.junit.jupiter.api.Test;

public class TestBankLoanService {

	@Test
	public void testCalSimpleInterestAmountWithSmallNumbers() {
			//.....
	}	
}
